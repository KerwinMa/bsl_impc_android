require(["zepto", "cube/session", 'cube/cube-form', 'cube/cube-dialog', "../com.foss.login.demo.login/login", "cube/store"],
		function($, Session, Form, Dialog, Login, Store) {

	//载入并销毁用户url
	var targetUrl = Session.loadObject('lasturl');
	Session.deleteObject('lasturl');

	var form = new Form({id: "login-form"});
	//屏蔽表单自动跳转
	$("#login-form").removeAttr('onSubmit').submit(function(e){
		return false;
	});


	//2. 登陆事件
	$("#login").click(function(){
		$(this).focus();
		var username = $("#username").val();
		var password = $("#password").val();
		//2.1 为空判断
		if( !username || username.trim().length==0 || !password || password.trim().length==0) {
			new Dialog({autoshow : true, target: 'body', title: '提示',content: '请输入员工号和密码！'},
				{configs:[{title:'确定',eventName:'ok'}],
					ok:function(){
					}
				}
			);
			return;
		}

		
		
		//2.3 登陆请求
		Login(username, password, function(){

			var loginUser = Store.loadObject("user");
			Store.clear();
			Store.saveObject("user", loginUser);
			//2.2 记住用户名和密码
			var remembermeVal = $("#rememberme").attr("checked");
			if(remembermeVal == "checked" || remembermeVal =="true") {
				var remembermeObj = {"username":username.trim(), "password":password.trim()};
				Store.saveObject("rememberme",remembermeObj);
			} else {
				Store.deleteObject("rememberme");
			}

			if(targetUrl && targetUrl.url) {
				window.location.href = targetUrl.url;
				return;
			}
			if(window.cordova) {
				cordova.exec(null,null, "LoginPlugin","LoginSuccess");
			} else {
				window.location.href = "../com.foss.flightstatus.demo/index.html";
			}
			
		}, function(){
			
		});
	});
});